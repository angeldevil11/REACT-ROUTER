function Home () {
	return (
		<div>
			<h1>Welcome to the Class Front End !!!</h1> 
			<h3>How are you today?</h3>
		</div>
	);
}
// about page
function About () {
	return(
		<div>
			<h2>Front-end web development is the development of the graphical 
			user interface of a website, through the use of HTML, CSS, and 
			JavaScript, so that users can view and interact with that website
			. </h2>

			Read more the article :
			<a href=
			"https://frontendmasters.com/guides/front-end-handbook/2019/">
				https://frontendmasters.com/guides/front-end-handbook/2019/

			</a>

		</div>
	);
}

